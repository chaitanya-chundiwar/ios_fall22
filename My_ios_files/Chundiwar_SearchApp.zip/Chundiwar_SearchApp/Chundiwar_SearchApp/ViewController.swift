//
//  ViewController.swift
//  Chundiwar_SearchApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 10/13/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var searchTextField: UITextField!

    
    @IBOutlet weak var searchButtonOutlet: UIButton!
    
        
    @IBOutlet weak var topicInfoText: UITextView!
   
    
    @IBOutlet weak var previousButtonOutlet: UIButton!
    
    
    @IBOutlet weak var nextButtonOutlet: UIButton!
    

    @IBOutlet weak var resultImage: UIImageView!
    
    
    
    var arr_img = [
        ["Actor1","Actor2","Actor3","Actor4","Actor5"]  ,
        ["Animal1","Animal2","Animal3","Animal4","Animal5"],
        ["Movie1","Movie2","Movie3","Movie4","Movie5"]]
        
  
    var actor_keywords = ["johnny depp","pirates","leonardo dicaprio","titanic","Inception","The Revenant","tony stark","iron man","vin diesel","anne Hathaway"]
    var animals_keywords = ["dog","horse","lion","fox","wolf","beer","bear","tiger","royal bengal tiger","bulldog","german shepherd"]
    var movie_keywords = ["avengers","titanic","lord of ring","fast and furious","harry potter"]
    
    var arry_topics = [
        ["Leonardo Wilhelm DiCaprio is an American actor and film producer. Known for his work as a leading man in biopics and period films, a British Academy Film Award, and three Golden Globe Awards",
         "Mark Sinclair (born July 18, 1967), known professionally as Vin Diesel, he is best known for playing Dominic Toretto in the Fast & Furious franchise.",
         "Iron Man is a superhero appearing in American comic books published by Marvel Comics. The character was co-created by writer and editor Stan Lee developed by scripter Larry Lieber, and designed by artists Don Heck and Jack Kirby.",
         "John Christopher Depp II is an American actor and musician. Known for his work in film, he has received multiple accolades, including a Golden Globe Award and a Screen Actors Guild Award ",
         "Anne Jacqueline Hathaway is an American actress. The recipient of various accolades, including an Academy Award, a Golden Globe Award, and a Primetime Emmy Award, she was among the world's highest-paid actresses in 2015."],
        ["The dog  is a domesticated descendant of the wolf. Also called the domestic dog, The dog was the first species to be domesticated, by hunter-gatherers over 15,000 years ago, before the development of agriculture.",
         "The tiger is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside. An apex predator, it primarily preys on ungulates, such as deer and wild boar.",
         "The wolf, also known as the gray wolf or grey wolf, is a large canine native to Eurasia and North America. More than thirty subspecies of Canis lupus have been recognized, and gray wolves, as popularly understood, comprise wild subspecies.",
         "The horse is a domesticated, one-toed, hoofed mammal. It belongs to the taxonomic family Equidae and is one of two extant subspecies of Equus ferus. The horse has evolved over the past 45 to 55 million years from a small multi-toed creature",
         "Bears are carnivoran mammals of the family Ursidae. They are classified as caniforms, or doglike carnivorans. Although only eight species of bears are extant, they are widespread, appearing in a wide variety of habitats throughout the Northern Hemisphere and partially in the Southern Hemisphere."],
        ["The film's development began when Marvel Studios received a loan from Merrill Lynch in April 2005. After the success of the film Iron Man in May 2008, Marvel announced that The Avengers would be released in July 2011",
         "James Cameron's Titanic is an epic, action-packed romance set against the ill-fated maiden voyage of the R.M.S. Titanic; the pride and joy of the White Star Line and, at the time, the largest moving object ever built. She was the most luxurious liner of her era -- the ship of dreams",
         "Fast & Furious is a media franchise centered on a series of action films that are largely concerned with street racing, heists, spies, and family. The franchise also includes short films, a television series, live shows, toys, video games and theme park attractions. It is distributed by Universal Pictures",
         "The Lord of the Rings is a series of three epic fantasy adventure films directed by Peter Jackson, based on The Lord of the Rings novels written by J. R. R. Tolkien. The films are subtitled The Fellowship of the Ring, The Two Towers, and The Return of the King.",
         "Harry Potter is a film series based on the eponymous novels by J. K. Rowling. The series is produced and distributed by Warner Bros. Pictures and consists of eight fantasy films, beginning with Harry Potter and the Philosopher's Stone and culminating with Harry Potter and the Deathly Hallows"]]
   
    var imgtopic:Int = 0
    var imageVal:Int = 0

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
                //disable prev and next
                nextButtonOutlet.isEnabled = false
                previousButtonOutlet.isEnabled = false
                searchButtonOutlet.isEnabled = false
                resultImage.image = UIImage(named: "not_found")

    }
   
    
    
    @IBAction func searchButtonEnabled(_ sender: Any) {
        let text = searchTextField.text!
        if(text.isEmpty){
            searchButtonOutlet.isEnabled = false
        }else{
            searchButtonOutlet.isEnabled = true
        }

    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
        let textValue = searchTextField.text!
        
        if(actor_keywords.contains(textValue)){
            imgtopic = 0
            imageVal = 0
            updateDetails(imgtopic,imageVal)
            
        }else if(animals_keywords.contains(textValue)){
            imgtopic = 1
            imageVal = 0
            updateDetails(imgtopic,imageVal)
           
        }else if(movie_keywords.contains(textValue)){
            imgtopic = 2
            imageVal = 0
            updateDetails(imgtopic,imageVal)
            
        }else{
            resultImage.image = UIImage(named: "wrong_input")
            topicInfoText.text = ""
            nextButtonOutlet.isEnabled = false
        }
        nextButtonOutlet.isEnabled = true

    }
    
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        imageVal = imageVal  + 1
        previousButtonOutlet.isEnabled = true
        if(imageVal == 4){
            nextButtonOutlet.isEnabled = false
        }
        updateDetails(imgtopic,imageVal)

    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        imageVal = imageVal - 1
                nextButtonOutlet.isEnabled = true
                if(imageVal == 0){
                    previousButtonOutlet.isEnabled = false
                }
                updateDetails(imgtopic,imageVal)

    }
    
    
    @IBAction func resetButton(_ sender: UIButton) {
        searchButtonOutlet.isHidden = true
                searchTextField.isHidden = true
                nextButtonOutlet.isHidden = true
                previousButtonOutlet.isHidden = true
                topicInfoText.isHidden = true
                imgtopic = 0
                imageVal = 0

    }
    
    func updateDetails(_ topic: Int,_ imageNum:Int){
        resultImage.image = UIImage(named: arr_img[topic][imageNum])
        topicInfoText.text = arry_topics[topic][imageNum]
        
    }

}
