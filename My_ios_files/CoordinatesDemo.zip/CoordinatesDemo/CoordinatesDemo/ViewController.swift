//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 10/13/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
   
        let minx = ImageViewOutlet.frame.minX
        let miny = ImageViewOutlet.frame.minY
        print(minx,",",miny)
        
        let maxx = ImageViewOutlet.frame.maxX
        let maxy = ImageViewOutlet.frame.maxY
        print(maxx,",",maxy)
        
        let midx = ImageViewOutlet.frame.midX
        let midy = ImageViewOutlet.frame.midY
        print(midx,",",midy)
        
        //Move the location to the upper left corner.
        
        ImageViewOutlet.frame.origin.x = 0
        ImageViewOutlet.frame.origin.y = 0
     
        //Move the location to the upper right corner.
        
        ImageViewOutlet.frame.origin.x = 314
        ImageViewOutlet.frame.origin.y = 0
        
        //Move the location to the bottom left corner.
        
        ImageViewOutlet.frame.origin.x = 0
        ImageViewOutlet.frame.origin.y = 796
        
        //Move the location to the bottom right corner.
        
        ImageViewOutlet.frame.origin.x = 314
        ImageViewOutlet.frame.origin.y = 796
        
        //Move the location of the object to center of the view.
        
        //(414/2)-50,(796/2)-50)
        ImageViewOutlet.frame.origin.x = 157
        ImageViewOutlet.frame.origin.y = 398
        
        
        
        
    }


}

