//
//  ViewController.swift
//  AnimationsDemo1
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 10/18/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    @IBOutlet weak var HappyOutlet: UIButton!
    
    @IBOutlet weak var SadOutlet: UIButton!
    
    @IBOutlet weak var AngryOutlet: UIButton!
    
    @IBOutlet weak var ShakeMeOutlet: UIButton!
    
    @IBOutlet weak var ShowOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Moving the image outside of the view.
               ImageViewOutlet.frame.origin.x = view.frame.maxX;
    }
    
    override func viewDidAppear(_ animated: Bool) {
            //Moving the image outside of the Screen view.
            ImageViewOutlet.frame.origin.x = view.frame.maxX;
            
            //similarly, do it for all the objects.
            //we do move only in horizontal direction.
            HappyOutlet.frame.origin.x = view.frame.width
            
            SadOutlet.frame.origin.x = view.frame.width
            
            AngryOutlet.frame.origin.x = view.frame.width
            
            ShakeMeOutlet.frame.origin.x = view.frame.width
            
        }

    @IBAction func HappyButtonClicked(_ sender: Any) {
        animateImage("happy")
    }
    
    @IBAction func SadButtonClicked(_ sender: Any) {
        animateImage("sad")
    }
    
    @IBAction func AngryButtonClicked(_ sender: Any) {
        animateImage("angry")
    }
    
    @IBAction func ShakeMeButtonClicked(_ sender: Any) {
        var width =  ImageViewOutlet.frame.width
                       width += 40
                       var height = ImageViewOutlet.frame.height
                       height += 40
                       
                      var x =  ImageViewOutlet.frame.origin.x-20
                       
                       var y = ImageViewOutlet.frame.origin.y-20
                       
                       var largerFrame = CGRect(x: x, y: y, width: width, height: height)
                       
                       UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                           self.ImageViewOutlet.frame = largerFrame
                       })
    }
    
    @IBAction func ShowButtonClicked(_ sender: Any) {
        UIView.animate(withDuration: 1,  animations: {
              //Moving all the components to the center of the screen (view)
                  self.ImageViewOutlet.center.x = self.view.center.x;
              
                  self.HappyOutlet.center.x = self.view.center.x;
              
                  self.SadOutlet.center.x = self.view.center.x;
              
                  self.AngryOutlet.center.x = self.view.center.x;
              
                  self.ShakeMeOutlet.center.x = self.view.center.x
              
              })
        self.ShowOutlet.isEnabled = false;
    }
    
    
    func animateImage(_ imageName: String){
           
           //Making the current image opaque. aplha is 0.
           
           UIView.animate(withDuration: 1, animations:{
               self.ImageViewOutlet.alpha = 0;
       
           } )
           
           
           //Assigning the new image with animation.and make it transparant with alpha is 1
           
           UIView.animate(withDuration: 1,delay: 0.2, animations:{
               
               self.ImageViewOutlet.alpha = 1;
           self.ImageViewOutlet.image = UIImage(named: imageName)
       
           } )
           
       }
}

