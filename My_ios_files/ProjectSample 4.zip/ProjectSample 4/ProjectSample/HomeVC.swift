//
//  HomeVC.swift
//  ProjectSample
//
//  Created by Thanguturi,Anjana on 12/3/22.
//

import UIKit

class HomeVC: UIViewController {
    
    var income = ""
    var expense = ""
    var categorySelected = ""
    
    var categoryIncomeDict = ["Salary" : 0.0,
                        "Other Income" : 0.0]
    
    var categoryExpenseDict = ["Food" : 0.0,
                        "Entertainment" : 0.0,
                        "Shopping" : 0.0,
                        "Utilities" : 0.0,
                        "General" : 0.0]
    
    @IBOutlet weak var incomeOutlet: UILabel!
    
    @IBOutlet weak var expenseOutlet: UILabel!
    
    @IBOutlet weak var balanceOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        let initialIncome = incomeOutlet.text!
        let initialExpense = expenseOutlet.text!
        if(initialIncome.isEmpty){
            if(!income.isEmpty){
                incomeOutlet.text = "\(Double(income)!)"
                categoryIncomeDict[categorySelected] = categoryIncomeDict[categorySelected]! + Double(income)!
                income = ""
            }
        }else{
            if(!income.isEmpty){
                incomeOutlet.text = "\(Double(initialIncome)! + Double(income)!)"
                categoryIncomeDict[categorySelected] = categoryIncomeDict[categorySelected]! + Double(income)!
                income = ""
            }
        }
        
        if(initialExpense.isEmpty){
            if(!expense.isEmpty){
                expenseOutlet.text = "\(Double(expense)!)"
                categoryExpenseDict[categorySelected] = categoryExpenseDict[categorySelected]! + Double(expense)!
                expense = ""
            }
        }else{
            if(!expense.isEmpty){
                expenseOutlet.text = "\(Double(initialExpense)! + Double(expense)!)"
                categoryExpenseDict[categorySelected] = categoryExpenseDict[categorySelected]! + Double(expense)!
                expense = ""
            }
        }
        
        if(!incomeOutlet.text!.isEmpty && !expenseOutlet.text!.isEmpty){
            balanceOutlet.text = "\(Double(incomeOutlet.text!)! - Double(expenseOutlet.text!)!)"
        }
        
    }
    
    @IBAction func unwindToHomeVC(segue: UIStoryboardSegue){
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        if transition == "homeToCategoryIncomeSegue"{
            
            let destination = segue.destination as! CategoryToIncomeVC
            
            destination.categoryIncomeMap = categoryIncomeDict
        }
        
        if transition == "homeToCategoryExpenseSegue"{
            let destination = segue.destination as! CategoryToExpenseVC
            
            destination.categoryExpenseMap = categoryExpenseDict
        }
    }
}
