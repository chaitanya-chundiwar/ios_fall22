//
//  CategoryToExpenseVC.swift
//  ProjectSample
//
//  Created by Thanguturi,Anjana on 12/3/22.
//

import UIKit

class CategoryToExpenseVC: UIViewController {

    @IBOutlet weak var categoryOutlet: UITextField!
    
    @IBOutlet weak var categoryExpenseLabel: UILabel!
    
    var categoryExpenseMap = [String:Double]()
    
    var selectedCategory:String?
    var categoryList = ["Food","Entertainment","Shopping","Utilities","General"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.createAndSetupPickerView()
        self.dismissAndClosePickerView()
    }
    
    func createAndSetupPickerView(){
        let pickerview = UIPickerView()
        pickerview.delegate = self
        pickerview.dataSource = self
        self.categoryOutlet.inputView = pickerview
    }
    
    func dismissAndClosePickerView(){
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let button = UIBarButtonItem(title: "Done", style: .plain, target: self, action:
                                        #selector(self.dismissAction))
        
        toolBar.setItems([button], animated: true)
        toolBar.isUserInteractionEnabled = true
        self.categoryOutlet.inputAccessoryView = toolBar
        
        
    }
    
    @objc func dismissAction(){
        self.view.endEditing(true)
    }
}

extension CategoryToExpenseVC: UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.categoryList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.categoryList[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.selectedCategory = self.categoryList[row]
        self.categoryOutlet.text = self.selectedCategory
        categoryExpenseLabel.text =
        "\(categoryExpenseMap[self.categoryOutlet.text!]!)"
    }
    
    
}

