//
//  ViewController.swift
//  ProjectSample
//
//  Created by Aluri,Hari Kiran on 11/16/22.
//

import UIKit

class LoginVC: UIViewController {

    
    @IBOutlet weak var userNameOutlet: UITextField!
    
    
    @IBOutlet weak var passwordOutlet: UITextField!
    
    @IBOutlet weak var loginButtonOutlet: UIButton!
    
    @IBOutlet weak var resetButtonOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loginButtonOutlet.isEnabled = false
        resetButtonOutlet.isEnabled = false
    }
    
    
    @IBAction func loginButtonClicked(_ sender: UIButton) {
        let userName = userNameOutlet.text!
        let password = passwordOutlet.text!
        if(userName == "Hari" && password == "Aluri" ||
           userName == "Anjana" && password == "Thanguturi" ||
           userName == "Srujan" && password == "Yeruva" ||
           userName == "Chaitanya" && password == "Chundiwar" ||
           userName == "Pragnya" && password == "Kalvakol"){
            self.performSegue(withIdentifier: "loginToHomeSegue", sender: self)
        }
    }
    
    @IBAction func resetButtonClicked(_ sender: UIButton) {
        userNameOutlet.text?.removeAll()
        passwordOutlet.text?.removeAll()
        
    }
    
    @IBAction func passwordFunction(_ sender: UITextField) {
       let password = passwordOutlet.text!
        if(!password.isEmpty){
            loginButtonOutlet.isEnabled = true
            resetButtonOutlet.isEnabled = true
        }
    }
}

