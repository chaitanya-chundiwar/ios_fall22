//
//  CheckoutTicketViewController.swift
//  Chundiwar_TicketCheckoutApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/8/22.
//

import UIKit

class CheckoutTicketViewController: UIViewController {
    
    var name = ""
    var airlines = ""
    var image = ""
    
    @IBOutlet weak var bookedName: UILabel!
    
    @IBOutlet weak var bookedFlightName: UILabel!
    
    @IBOutlet weak var checkoutFlightImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        bookedFlightName.numberOfLines = 2
        bookedName.text = "\(name) your checkout is successfull!!"
        bookedFlightName.text = "\(name) you will be flying through \n\(airlines)"
        checkoutFlightImage.image = UIImage(named: image)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
