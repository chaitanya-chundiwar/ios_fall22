//
//  ViewController.swift
//  Chundiwar_TicketCheckoutApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/8/22.
//

import UIKit

class AvalabilityCheckViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var bookingId: UITextField!
    
    
    @IBOutlet weak var bookingStatus: UILabel!
    
    
    @IBOutlet weak var flightBookedImage: UIImageView!
    
    
    @IBOutlet weak var ticketCheckOut: UIButton!
    
    var bookingFound = Ticket()
    
    //to check whether user is in Bookinglist/guest
    //Initially isBooking is false that means user is a guest
    var isBooking = false
    
    //Array of type Student, we imported it from the 'Ticket' file
    var bookingArray = TicketsArray
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        name.text = ""
        bookingId.text = ""
        flightBookedImage.image = UIImage(named: "default")
        ticketCheckOut.isEnabled = false
    }


    @IBAction func ticketBookedAvalability(_ sender: Any) {
        let bookingID = bookingId.text!
        
        for booking in bookingArray {
            if (bookingID == booking.bookingID){
                bookingStatus.text = ""
                bookingStatus.text = "\(bookingID) is Found"
                flightBookedImage.image = UIImage(named: booking.airlineImage)
                isBooking = true
                bookingFound = booking
            }
        }
        if(isBooking){
            ticketCheckOut.isEnabled = true
        }
            else{
                bookingStatus.text = ""
                bookingStatus.text = "Booking ID Not Found!"
                viewDidLoad()
            }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "checkoutSegue"{
            let destination = segue.destination as! CheckoutTicketViewController
            destination.name = ""
            destination.airlines = ""
            destination.image = ""
            if isBooking {
                destination.name = name.text!
                destination.airlines = bookingFound.airlineName
                destination.image = bookingFound.airlineImage
                isBooking = false
            }
        }
        viewDidLoad()
        bookingStatus.text = ""
        bookingStatus.text = "Status"
    }
}

