//
//  ViewController.swift
//  Chundiwar_MovieDisplayApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/29/22.
//

import UIKit

class MovieSectionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hollywoodMovies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "movieSectionCell", for: indexPath)
        cell.textLabel?.text = hollywoodMovies[indexPath.row].movieName
        
        return cell
    }
    
    var hollywoodMovies = MovieArray
    
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieInfoSegue"{
            let destination = segue.destination as! MovieInfoViewController
            destination.hollywoodMovieImage = hollywoodMovies[(tableViewOutlet.indexPathForSelectedRow?.row)!].movieImage
            destination.hollywoodMovieName = hollywoodMovies[(tableViewOutlet.indexPathForSelectedRow?.row)!].movieName
            destination.hollywoodMovieCast = hollywoodMovies[(tableViewOutlet.indexPathForSelectedRow?.row)!].movieCast
            destination.hollywoodMovieRelYear = hollywoodMovies[(tableViewOutlet.indexPathForSelectedRow?.row)!].movieReleasedYear
            destination.hollywoodMovieColl = hollywoodMovies[(tableViewOutlet.indexPathForSelectedRow?.row)!].boxOfficeCollection
            
            
        }
    }
    
    
}

