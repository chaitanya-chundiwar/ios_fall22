//
//  MovieInfoViewController.swift
//  Chundiwar_MovieDisplayApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/29/22.
//

import UIKit

class MovieInfoViewController: UIViewController {

    
    var hollywoodMovieImage = ""
    var hollywoodMovieName = ""
    var hollywoodMovieCast = ""
    var hollywoodMovieRelYear = ""
    var hollywoodMovieColl = ""
    
    @IBOutlet weak var imageViewMovieOutlet: UIImageView!
    
    @IBOutlet weak var hollywoodMovieNameOutlet: UILabel!
    
    @IBOutlet weak var hollywoodMovieCastOutlet: UILabel!
    
    @IBOutlet weak var hollywoodMovieReleasedYear: UILabel!
    
    @IBOutlet weak var hollywoodMovieCollection: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = hollywoodMovieName
        imageViewMovieOutlet.image = UIImage(named: hollywoodMovieImage)
        hollywoodMovieNameOutlet.text = "Movie Name: \(hollywoodMovieName)"
        hollywoodMovieCastOutlet.text = "Movie Cast: \(hollywoodMovieCast)"
        hollywoodMovieReleasedYear.text = "Movie Cast: \(hollywoodMovieRelYear)"
        hollywoodMovieCollection.text = "Movie Cast: \(hollywoodMovieColl)"
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
