//
//  MovieData.swift
//  Chundiwar_Movies
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/30/22.
//

import Foundation
import UIKit
struct Movie{
    let title:String
    let image:UIImage
    let releasedYear:String
    let movieRating:String
    let boxOffice:String
    let moviePlot:String
    let cast:[String]
}
struct Genre
{
    let category:String
    let movie:[Movie]

}

let g1 = Genre(category: "Fantasy", movie: [Movie(title: "Akhanda", image: UIImage(named: "akanda")!, releasedYear: "2021", movieRating: "6.8", boxOffice: "120 crores", moviePlot:"A child is taken in by Aghora, becoming a fierce devotee of Lord Shiva, living up to his destiny to stand tall against evildoers.", cast: ["Nandamuri Balakrishna","Pragya Jaiswal"]),
Movie(title:"Dana veera sura karna", image: UIImage(named: "dvsk")!, releasedYear: "1997", movieRating: "9.0", boxOffice: "2 crores", moviePlot: "A baby has been rescued from the Ganga river by charioteer Adhiratha, who adopts the boy and names him Karna. Years later, Karna witnesses the scene of Dronacharya taking off Ekalavya's thumb", cast:["N.t.rama Rao","B. Saroja Devi"]),
Movie(title: "I Movie", image: UIImage(named: "imovie")!, releasedYear: "2015", movieRating: "7.3", boxOffice: "240 crores", moviePlot: "I is a 2015 Indian Tamil-language romantic action thriller film written and directed by S. Shankar. the film features Vikram, Amy Jackson and Suresh Gopi in lead roles while Santhanam, Upen Patel, Ojas Rajani (in her film debut) and Ramkumar Ganesan portray pivotal roles.", cast: ["Vikram","Amy Jackson","Suresh Gopi"]),
Movie(title: "Puli", image: UIImage(named: "puli")!, releasedYear: "2015", movieRating: "4.3", boxOffice: "101Crores", moviePlot: "Marudheeran (half tiger-demon and half human) is the adopted son of a tribal village chief named Vembunathan. When he becomes an adult, Marudheeran starts to protect the villagers from the Vedhalams, because of which he is well respected by the villagers.", cast: ["Vijay","Sridevi","Sudeep"]),
Movie(title:"Anaganaga o dheerudu",image:UIImage(named:"anod")!, releasedYear: "2011", movieRating: "5.3", boxOffice: "51 crores", moviePlot: "Irendri (Lakshmi Manchu) is a sorceress who terrorizes people of Anga Rajyam. A guru arrests her, doesn't allow her to play with the lives of people, and destroys her. Before she was destroyed, Irendri takes her soul away and traps it in a locket.", cast: ["Siddharth","Shruti Haasan"])])

let g2 = Genre(category: "Sci-Fi", movie: [Movie(title: "Fast and furious 9", image: UIImage(named: "faf")!, releasedYear: "2021", movieRating: "5.2", boxOffice: "1200 crores", moviePlot:"Fast & Furious is a media franchise centered on a series of action films that are largely concerned with street racing, heists, spies, and family. The franchise also includes short films, a television series, live shows, toys, video games and theme park attractions.", cast: ["Vin Diesel","Justin Lin"," James Wan"]),
Movie(title:"Moonfall", image: UIImage(named: "moonfall")!, releasedYear: "2022", movieRating: "5.1", boxOffice: "53 crores", moviePlot: "The world stands on the brink of annihilation when a mysterious force knocks the moon from its orbit and sends it hurtling toward a collision course with Earth. With only weeks before impact, impossible mission into space to save humanity.", cast:["Roland Emmerich", "Harald Kloser"]),
Movie(title: "Dune", image: UIImage(named: "dune")!, releasedYear: "2022", movieRating: "8.0", boxOffice: "140 crores", moviePlot: "Paul Atreides, a brilliant and gifted young man born into a great destiny beyond his understanding,  As malevolent forces explode into conflict over the planet's exclusive supply of the most precious resource in existence, only those who can conquer their own fear will survive. ", cast: ["Jon Spaihts","‎Denis Villeneuve‎"]),
Movie(title: "Tenet", image: UIImage(named: "tenet")!, releasedYear: "2020", movieRating: "7.3", boxOffice: "410 Crores", moviePlot: "A secret agent is given a single word as his weapon and sent to prevent the onset of World War III. He must travel through time and bend the laws of nature in order to be successful in his mission.", cast: ["Emma Thomas","Christopher"]),
Movie(title:"Alita",image:UIImage(named:"alita")!, releasedYear: "2020", movieRating: "7.3", boxOffice: "659 crores", moviePlot: "A secret agent is given a single word as his weapon and sent to prevent the onset of World War III. He must travel through time and bend the laws of nature in order to be successful in his mission.", cast: ["Christopher Nolan","Robert Pattinson"])])

let g3 = Genre(category: "Comedy", movie: [Movie(title: "Paagal", image: UIImage(named: "paagal")!, releasedYear: "2021", movieRating: "5.6", boxOffice: "74 crores", moviePlot:"Prem, an 8-year-old boy is taken care of by his mother (Bhumika Chawla). He loves his mother very much and so does his mother. They live happily but one day, his mother dies of cancer without proper medication.", cast: ["Vishwak Sen","Nivetha Pethuraj"]),
Movie(title:"Julayi", image: UIImage(named: "julayi")!, releasedYear: "2012", movieRating: "7.2", boxOffice: "125 crores", moviePlot: "A master-robber named Bittu and a local MLA named Varadarajulu plan. Ravindra Narayan believes in earning quick money rather than toiling like his father Narayana Moorthy", cast:["Allu Arjun","Ileana D'Cruz"]),
Movie(title: "Jathiratnalu", image: UIImage(named: "jathiratnalu")!, releasedYear: "2021", movieRating: "7.3", boxOffice: "70.57 crores", moviePlot: "Chanakya bails them out and his men take them to a den and enquires them Srikanth overhears that they are going to be killed as soon as Chanakya gets hold of the mobile. ", cast: ["Naveen Polishetty","Priyadarshi","Rahul Ramakrishna"]),
Movie(title: "Don", image: UIImage(named: "don")!, releasedYear: "2022", movieRating: "6.9", boxOffice: "130 Crores", moviePlot: "Chakaravarthi's father, Ganesan, is a strict father who cares a lot about Chakaravarthi's studies and wants him to be a civil engineer. But Chakaravarthi hates studying and lies to his father about his test marks. ", cast: ["Sivakarthikeyan","S. J. Suryah","Samuthirakani"]),
Movie(title:"Doctor",image:UIImage(named:"doctor")!, releasedYear: "2021", movieRating: "7.4", boxOffice: "100 crores", moviePlot: "Varun, a military doctor working in the Indian Army Medical Corps is a strict and practical person. who urges him to call off their upcoming wedding. While enquiring about her sudden change-of-decision with her family.", cast: ["Kotapadi J. Rajesh","Priyanka Arul Mohan"])])


let genreArray = [g1,g2,g3]
