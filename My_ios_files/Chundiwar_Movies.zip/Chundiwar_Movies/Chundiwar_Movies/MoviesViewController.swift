//
//  MoviesViewController.swift
//  Chundiwar_Movies
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/29/22.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for:indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: cinema[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cinema.count
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            assignMovieDetails(index: indexPath)
        }
        
        func assignMovieDetails(index:IndexPath){
            movieNameLabel.text = "Movie Name: \(cinema[index.row].title)"
            movieRatingLabel.text = "Movie Rating: \(cinema[index.row].movieRating)"
            movieBoxOfficeLabel.text = "Box Office Collection: \(cinema[index.row].boxOffice)"
                    movieYearLabel.text = "Movie Released Year: \(cinema[index.row].releasedYear)"
            moviePlotLabel.numberOfLines = 0
            moviePlotLabel.text = "Plot: \(cinema[index.row].moviePlot)"
                    var castMovieString = ""
                    for data in cinema[index.row].cast{
                        castMovieString = castMovieString + data + ","
                    }
                    movieCastLabel.text = "Cast: \(castMovieString)"
        }


    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    @IBOutlet weak var movieCastLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = category
        movieCollectionView.delegate = self
        movieCollectionView.dataSource = self
        // Do any additional setup after loading the view.
    }
   
    var category: String = ""
    var cinema: [Movie] = []

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
