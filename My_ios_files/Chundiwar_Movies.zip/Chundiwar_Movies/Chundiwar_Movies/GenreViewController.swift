//
//  ViewController.swift
//  Chundiwar_Movies
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/29/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genreArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for:indexPath)
        cell.textLabel?.text = genres[indexPath.row].category
        return cell
    }
    
    let genres = genreArray
    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Movies App"
        genreTableView.delegate = self
        genreTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let destination = segue.destination as! MoviesViewController
            destination.category = genres[(genreTableView.indexPathForSelectedRow?.row)!].category
            destination.cinema = genres[(genreTableView.indexPathForSelectedRow?.row)!].movie
        }
    }

}

