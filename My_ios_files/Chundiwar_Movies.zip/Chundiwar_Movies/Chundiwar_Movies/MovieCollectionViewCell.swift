//
//  MovieCollectionViewCell.swift
//  Chundiwar_Movies
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/30/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageCollectionView: UIImageView!
    func assignMovie(with movie:Movie){
        imageCollectionView.image = movie.image
    }
}
