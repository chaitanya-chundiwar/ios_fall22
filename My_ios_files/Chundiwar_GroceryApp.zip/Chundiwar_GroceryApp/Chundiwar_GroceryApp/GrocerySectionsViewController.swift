//
//  ViewController.swift
//  Chundiwar_GroceryApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/10/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sectionsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell",for: indexPath)
        cell.textLabel?.text = sectionsArray[indexPath.row].section
        return cell
    }
    
    var sectionsArray = sections
    
        
    @IBOutlet weak var grocerySectionsTableView: UITableView!
   

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Grocery Sections"
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
                if transition == "itemsSegue"{
                  
                    let destination = segue.destination as! GroceryItemsViewController
                    
                    destination.items_Array = sectionsArray[(grocerySectionsTableView.indexPathForSelectedRow?.row)!].items_Array
                    
                    
                }
    }
}

