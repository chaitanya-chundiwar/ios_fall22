//
//  GrocerySections.swift
//  Chundiwar_GroceryApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 11/17/22.
//

import Foundation

struct GrocerySections{
    var section = ""
    var items_Array:[GroceryItem] = []
}

struct GroceryItem{
    var itemName = ""
    var itemImage = ""
    var itemInfo = ""
}

let section1 = GrocerySections(section: "Meat",items_Array: [GroceryItem(itemName: "Chicken", itemImage: "chicken", itemInfo: "he chicken is a domesticated junglefowl species, with attributes of wild species such as the grey and the Ceylon junglefowl that are originally from Southeastern Asia. Rooster or cock is a term for an adult male bird, and a younger male may be called a cockerel. A male that has been castrated is a capon"),
    GroceryItem(itemName: "Beaf", itemImage: "beaf", itemInfo: "Beef is the culinary name for meat from cattle. In prehistoric times, humankind hunted aurochs and later domesticated them. Since that time, numerous breeds of cattle have been bred specifically for the quality or quantity of their meat"),
    GroceryItem(itemName: "Pork", itemImage: "pork", itemInfo: "Pork is the culinary name for the meat of the domestic pig. It is the most commonly consumed meat worldwide, with evidence of pig husbandry dating back to 5000 BCE. Pork is eaten both freshly cooked and preserved; curing extends the shelf life of pork products. "),
    GroceryItem(itemName: "Fish", itemImage: "fish", itemInfo: "A fish fillet, from the French word filet meaning a thread or strip, is the flesh of a fish which has been cut or sliced away from the bone by cutting lengthwise along one side of the fish parallel to the backbone. In preparation for filleting, any scales on the fish should be removed"),
    GroceryItem(itemName: "Prawn", itemImage: "prawn", itemInfo: "Prawn is a common name for small aquatic crustaceans with an exoskeleton and ten legs, some of which can be eaten.  ")])

let section2 = GrocerySections(section: "Cake", items_Array: [GroceryItem(itemName: "Venila", itemImage: "venila", itemInfo: "With its outstanding vanilla flavor, pillowy soft crumb, and creamy vanilla buttercream, this is truly the best vanilla cake I've ever had."),
    GroceryItem(itemName: "Icecream", itemImage: "icecream", itemInfo: "Ice cream is a sweetened frozen food typically eaten as a snack or dessert. It may be made from milk or cream and is flavoured with a sweetener, either sugar or an alternative,"),
    GroceryItem(itemName: "Butter", itemImage: "butter", itemInfo: "Butter is a dairy product made from the fat and protein components of churned cream. It is a semi-solid emulsion at room temperature, consisting of approximately 80% butterfat."),
    GroceryItem(itemName: "Cheese", itemImage: "cheese", itemInfo: "Cheese is a dairy product produced in wide ranges of flavors, textures, and forms by coagulation of the milk protein casein."),
    GroceryItem(itemName: "Yogurt", itemImage: "yogurt", itemInfo: "Yogurt is a food produced by bacterial fermentation of milk. The bacteria used to make yogurt are known as yogurt cultures.")])

let section3 = GrocerySections(section: "masala", items_Array: [GroceryItem(itemName: "Turmeric", itemImage: "turmeric", itemInfo: "Turmeric is a common spice and a major ingredient in curry powder. Curcumin is a major component of turmeric, and the activities of turmeric are commonly "),
    GroceryItem(itemName: "Garlic", itemImage: "garlic", itemInfo: "Allium sativum, commonly known as garlic, is a species in the onion family Alliaceae."),
    GroceryItem(itemName: "Pepper", itemImage: "pepper", itemInfo: "Black pepper (Piper nigrum) is a flowering vine in the family Piperaceae, cultivated for its fruit, known as a peppercorn"),
    GroceryItem(itemName: "Chille", itemImage: "chille", itemInfo: "This simple vegetarian chili recipe tastes incredible! It's easy to make with basic pantry ingredients, vegetables and spices. Gluten free and easily vegan."),
    GroceryItem(itemName: "Rice", itemImage: "rice", itemInfo: "Rice is the seed of the grass species Oryza sativa or less commonly Oryza glaberrima. The name wild rice is usually used for species of the genera Zizania and Porteresia, both wild and domesticated, although the term may also be used for primitive or uncultivated varieties of Oryza. .")])

let sections = [section1,section2,section3]
