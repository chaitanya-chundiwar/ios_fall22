//
//  ViewController.swift
//  Chundiwar_BillApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 10/4/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var productNameOutlet: UITextField!
  
    
    @IBOutlet weak var numberOfUnitsOutlet: UITextField!
    
    
    @IBOutlet weak var beforeDiscountDisplay: UILabel!
    
    
    @IBOutlet weak var afterDiscountDisplay: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func calculatedDiscountValue(_ sender: UIButton) {
        var numberOfUnits  = Int(numberOfUnitsOutlet.text!)
        var productName = productNameOutlet.text!
        if(productName=="Perfume"){
            
            let totalvalue_Perfume = numberOfUnits! * 10
           let perfume_Discount = totalvalue_Perfume - (totalvalue_Perfume*2/100)
            
                beforeDiscountDisplay.text = "Total Price before Discount \r for  \(productName) is $ \(totalvalue_Perfume)"
            
           
            afterDiscountDisplay.text = "Total Price before Discount \r for \(productName) is $ \(perfume_Discount)"
            
        }
        else if(productName=="T-Shirt"){
            let totalvalue_TShirt = numberOfUnits! * 35
           let TShirt_Discount = totalvalue_TShirt - (totalvalue_TShirt*4/100)
            
            beforeDiscountDisplay.text = "Total Price before Discount \r for \(productName) is $ \(totalvalue_TShirt)"
        
       
        afterDiscountDisplay.text = "Total Price before Discount for \r \(productName) is $ \(TShirt_Discount)"
        }else{
            let totalvalue_anyProduct = numberOfUnits!
           let anyProduct_Discount = totalvalue_anyProduct - (totalvalue_anyProduct*0/100)
            beforeDiscountDisplay.text = "Total Price before Discount \r for \(productName) is $ \(totalvalue_anyProduct)"
        
       
        afterDiscountDisplay.text = "Total Price before Discount \r for \(productName) is $ \(anyProduct_Discount)"
        }
            
    }
    
    
    
}

