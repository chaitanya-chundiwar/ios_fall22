//
//  ViewController.swift
//  ImageSliderApp
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 9/29/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var displayimageOutlet: UIImageView!
    
    
    @IBOutlet weak var crsNumOutlet: UILabel!
    
    
    @IBOutlet weak var crsTitleOutlet: UILabel!
   
    
    @IBOutlet weak var semOfferedOutlet: UILabel!
   
    
    @IBOutlet weak var previousButtonOutlet: UIButton!
  
    
    @IBOutlet weak var nextButtonOutlet: UIButton!
    let courses = [
    ["Img01","44555","Network Sequrity","fall 2022"],
     ["Img03","44556","Mobile Edge","Spring 2023"],
     ["Img02","44557","Data Streaming","Summar 2023"]]
    
    var imageNum = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Display the first course (0th index) details.
        
      //  displayimageOutlet.image = UIImage(named: courses[0][0])
    //    crsNumOutlet.text = courses[0][1]
    //    crsTitleOutlet.text = courses[0][2]
    //    semOfferedOutlet.text = courses[0][3]
        
        
        //Display the first course (0th index) details.
        updateDetails(0)
        
    //Previous Button is disabled.
        previousButtonOutlet.isEnabled = false
    }

    
    @IBAction func onClickedPrevious(_ sender: UIButton) {
       
        //displayimageOutlet.image = UIImage(named: courses[imageNum][0])
      //  crsNumOutlet.text = courses[imageNum][1]
       // crsTitleOutlet.text = courses[imageNum][2]
       // semOfferedOutlet.text = courses[imageNum][3]
        
        //decrementing image number.
        imageNum -= 1
        
        //display course details.
       updateDetails(imageNum)
        
        //Next Button should be enable
        nextButtonOutlet.isEnabled = true
        
        
        //
       // if(imageNum == courses.count-1)
      if(imageNum == 0)
        {
            //
            previousButtonOutlet.isEnabled = false
        }
    }
    
    
    
    @IBAction func onClickedNext(_ sender: UIButton) {
        // the details of image is displayed
     //   displayimageOutlet.image = UIImage(named: courses[imageNum][0])
     //   crsNumOutlet.text = courses[imageNum][1]
    //    crsTitleOutlet.text = courses[imageNum][2]
    //    semOfferedOutlet.text = courses[imageNum][3]
        
        //The details of the next course should be displayed.
        imageNum += 1
        
        updateDetails(imageNum)
        
        //previous Button should be enabled
        previousButtonOutlet.isEnabled = true
        
        //Once reaching end of array, next button should be disabled.
        if(imageNum == courses.count-1){
            //next button should be disabled.
            nextButtonOutlet.isEnabled = false
        }
    }
    
    
    func updateDetails(_ imageNum:Int){
        displayimageOutlet.image = UIImage(named: courses[imageNum][0])
        crsNumOutlet.text = courses[imageNum][1]
        crsTitleOutlet.text = courses[imageNum][2]
        semOfferedOutlet.text = courses[imageNum][3]
    }
}

