//
//  ViewController.swift
//  Chundiwar_WordGuess
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 10/27/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var guessLetterButton: UIButton!
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    var enterWord = [["GOOGLE","Top Search Engine","img001"],
                    ["SHARK","King of Water","img002"],
                    ["TOKYO","Advanced Developed City","img003"],
                    ["BANANA","Healthy Fruit","img004"],
                    ["NIKE","Popular Shoe Brand","img005"]]
    
    var guessedLetter = ""
    var game = 0
    var over = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        over = enterWord[game][0]
        userGuessLabel.text = ""
        updateUnderscores();
        guessLetterButton.isEnabled = false;
        
        
        hintLabel.text = hintLabel.text! + enterWord[game][1];
        playAgainButton.isHidden = true;
        
        
        statusLabel.text = "This is a status label of An App";
        totalWordsLabel.text = totalWordsLabel.text!.components(separatedBy: ":")[0] + ": \(enterWord.count)";
        wordsGuessedLabel.text = wordsGuessedLabel.text!.components(separatedBy: ":")[0] + ": 0";
        wordsRemainingLabel.text = wordsRemainingLabel.text!.components(separatedBy: ":")[0] + ": \(enterWord.count)"
        displayImage.image = nil
    }

    func updateUnderscores(){
        for _ in over{
            userGuessLabel.text! += "- "
        }
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
        let alpha_Letter = guessLetterField.text!
        
        guessedLetter = guessedLetter + alpha_Letter
        var gameLetter = ""
        print(over)
        for li in over{
            if guessedLetter.contains(li){
                gameLetter += "\(li)"
            }
            else{
                gameLetter += "_ "
            }
        }
        
        userGuessLabel.text = gameLetter
        guessLetterField.text = ""
        
        
        if userGuessLabel.text!.contains("_") == false{
            playAgainButton.isHidden = false;
            guessLetterButton.isEnabled = false;
            displayImage.image = UIImage(named: enterWord[game][2])
            let imgReveled = wordsRemainingLabel.text!.components(separatedBy: ":")
            wordsRemainingLabel.text = imgReveled[0] + ": \(enterWord.count - game - 1)"
            wordsGuessedLabel.text = wordsGuessedLabel.text!.components(separatedBy: ":")[0] + ": \(game+1)"
        }
        guessLetterButton.isEnabled = false
    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        
        playAgainButton.isHidden = true
        statusLabel.numberOfLines = 2
        guessedLetter = ""
        game = game + 1
        
        if game == enterWord.count{
            displayImage.image = UIImage(named: "img006")
            statusLabel.text = "Congratulations, You are done, \nPlease start over again"
            userGuessLabel.text = ""
            hintLabel.text = ""
            playAgainButton.isHidden = false
            game = -1;
            
        }
        else{
            if(statusLabel.text! == "Congratulations, You are done, \nPlease start over again"){
                viewDidLoad();
            }
            over = enterWord[game][0]
            hintLabel.text = "Hint: "
            hintLabel.text! += enterWord[game][1]
            userGuessLabel.text = ""
            updateUnderscores()
        }
    }
    
    
    @IBAction func guessedLetterTextField(_ sender: Any) {
        var word_Pressed = guessLetterField.text!;
        word_Pressed = String(word_Pressed.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = word_Pressed
        if word_Pressed.isEmpty{
            guessLetterButton.isEnabled = false
        }
        else{
            guessLetterButton.isEnabled = true
        }
    }
    
}
