//
//  ViewController.swift
//  MultiViewController
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 10/25/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AmountOutlet: UITextField!
    
    @IBOutlet weak var DiscountRateOutlet: UITextField!
    
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalcDiscountResult(_ sender: UIButton) {
        //Read the text from text field
        var amount = Double(AmountOutlet.text!)
        print(amount)
      
        var discountRate = Double(DiscountRateOutlet.text!)
        print(discountRate)
    
        priceAfterDiscount = amount! - (amount!*discountRate!/100)
        print(priceAfterDiscount)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "resultSeguae"{
            var destination = segue.destination as! MultiViewController
            destination.amount = AmountOutlet.text!
            destination.discRate = DiscountRateOutlet.text!
            destination.priceAfterDisc = String (priceAfterDiscount)
            
            AmountOutlet.text = ""
            DiscountRateOutlet.text = ""
        }
    }
}

