//
//  ViewController.swift
//  Chundiwar_Calculator
//
//  Created by Chundiwar,Chaitanyakrishna Hanumantarao on 9/26/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var CalculatedResult: UILabel!
    
    var operand1 = ""
    var operand2 = ""
    var calcOperator:Character = " "

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func ButtonClicked_AC(_ sender: UIButton) {
        CalculatedResult.text = " "
        calcOperator = " "
        operand1 = ""
        operand2 = ""

    }
    
    
    
    @IBAction func ButtonClicked_C(_ sender: UIButton) {
        CalculatedResult.text=" "
    }
    
    
    @IBAction func ButtonClicked_Change(_ sender: UIButton) {
        if(Int(CalculatedResult.text!)! > 0 ){
            CalculatedResult.text = "-"+CalculatedResult.text!
        }else
        {
                    let str: String = CalculatedResult.text!
                    CalculatedResult.text = String(str[str.index(after: str.startIndex) ..< str.endIndex])
            }
    }
    
    
    @IBAction func ButtonClicked_Division(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "/"
        if(calcOperator == " "){
            calcOperator = "/"
        }

    }
    
    
    @IBAction func ButtonClicked_Multiplication(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "*"
                if(calcOperator == " "){
                    calcOperator = "*"
        }
    }
    
    
    @IBAction func ButtonClicked_Minus(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "-"
                if(calcOperator == " "){
                    calcOperator = "-"
    }
    
}
    @IBAction func ButtonClicked_Plus(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "+"
                if(calcOperator == " "){
                    calcOperator = "+"
        }
    }
    
    
    @IBAction func ButtonClicked_Equals(_ sender: UIButton) {
        if(calcOperator == "+"){
            CalculatedResult.text = "\(Int(Double(operand1)! + Double(operand2)!))"
        }else if(calcOperator == "-"){
            CalculatedResult.text = "\(Int(Double(operand1)! - Double(operand2)!))"
        }else if(calcOperator == "*"){
            CalculatedResult.text = "\(Int(Double(operand1)! * Double(operand2)!))"
        }else if(calcOperator == "%"){
            let modul:Double = Double(operand1)!.truncatingRemainder(dividingBy: Double(operand2)!)
            CalculatedResult.text = "\(round(modul * 100)/100)"
        }else{
            let div = "\(Double(operand1)! / Double(operand2)!)"
            if(div == "inf"){
            CalculatedResult.text = "Error"
            }else{
            CalculatedResult.text = "\(round(Double(div)! * 100000)/100000)"
            }
        }

    }
    
    
    @IBAction func ButtonClicked_Modulas(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "%"
                if(calcOperator == " "){
                    calcOperator = "%"
                }

    }
    
    
    @IBAction func ButtonClicked_Decimal(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "."
        if(calcOperator == " "){
            operand1 = operand1 + "."
        }else{
            operand2 = operand2 + "."
        }

    }
    
    
    @IBAction func ButtonClicked_0(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "0"
                if(calcOperator == " "){
                    operand1 = operand1 + "0"
                }else{
                    operand2 = operand2 + "0"
                }
    }
    
    
    @IBAction func ButtonClicked_1(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "1"
                if(calcOperator == " "){
                    operand1 = operand1 + "1"
                }else{
                    operand2 = operand2 + "1"
                }
    }
    
    
    @IBAction func ButtonClicked_2(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "2"
                if(calcOperator == " "){
                    operand1 = operand1 + "2"
                }else{
                    operand2 = operand2 + "2"
                }
    }
    
    
    @IBAction func ButtonClicked_3(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "3"
                if(calcOperator == " "){
                    operand1 = operand1 + "3"
                }else{
                    operand2 = operand2 + "3"
                }
    }
    
    
    @IBAction func ButtonClicked_4(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "4"
                if(calcOperator == " "){
                    operand1 = operand1 + "4"
                }else{
                    operand2 = operand2 + "4"
                }
    }
    
    
    @IBAction func ButtonClicked_5(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "5"
                if(calcOperator == " "){
                    operand1 = operand1 + "5"
                }else{
                    operand2 = operand2 + "5"
                }
    }
    
    
    @IBAction func ButtonClicked_6(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "6"
                if(calcOperator == " "){
                    operand1 = operand1 + "6"
                }else{
                    operand2 = operand2 + "6"
                }
    }
    
    
    @IBAction func ButtonClicked_7(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "7"
                if(calcOperator == " "){
                    operand1 = operand1 + "7"
                }else{
                    operand2 = operand2 + "7"
                }
    }
    
    
    @IBAction func ButtonClicked_8(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "8"
                if(calcOperator == " "){
                    operand1 = operand1 + "8"
                }else{
                    operand2 = operand2 + "8"
                }
    }
    
    
    @IBAction func ButtonClicked_9(_ sender: UIButton) {
        CalculatedResult.text = CalculatedResult.text! + "9"
                if(calcOperator == " "){
                    operand1 = operand1 + "9"
                }else{
                    operand2 = operand2 + "9"
                }
    }
}

